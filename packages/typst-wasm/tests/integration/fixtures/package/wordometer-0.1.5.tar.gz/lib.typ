#let word-count-of(body) = body
